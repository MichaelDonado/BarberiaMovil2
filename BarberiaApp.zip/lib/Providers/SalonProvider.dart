import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../Models/Salon_model.dart'; // Importa el modelo 'Salon_model.dart' desde la carpeta 'Models'.

class Salon {
  final String? razonSocial;
  final String? direccionComercial;

  Salon({this.razonSocial, this.direccionComercial});

  factory Salon.fromJson(Map<String, dynamic> json) {
    return Salon(
      razonSocial: json["razon_social"],
      direccionComercial: json["direccion_comercial"],
    );
  }
}

// Clase para representar la estructura de un salón.
// Tiene atributos 'razonSocial' y 'direccionComercial'.
// El constructor 'fromJson' convierte un mapa JSON en un objeto 'Salon'.

class SalonProvider extends ChangeNotifier {
  List<Salon> _salon = [];
  List<Salon> get salon => _salon;

  // Lista privada '_salon' que almacena los salones obtenidos.
  // Getter 'salon' para acceder a la lista de salones desde fuera de la clase.

  Future<void> fetchsalons() async {
    try {
      final response = await http
          .get("https://www.datos.gov.co/resource/e27n-di57.json" as Uri);

      // Realiza una solicitud GET al endpoint proporcionado.

      if (response.statusCode == 200) {
        Iterable list = json.decode(response.body);
        _salon = list.map((model) => Salon.fromJson(model)).toList();
        notifyListeners(); // Notifica a los oyentes (como widgets) que la lista ha sido actualizada.
      } else {
        throw Exception("Fallo la conexión");
      }
    } catch (error) {
      throw Exception("Error: $error");
    }
  }
}

// Clase 'SalonProvider' que extiende 'ChangeNotifier' para que pueda notificar a los oyentes sobre cambios.
// El método 'fetchsalons' realiza la llamada al endpoint, decodifica la respuesta y actualiza la lista de salones.
// Si ocurre un error, lanza una excepción.
