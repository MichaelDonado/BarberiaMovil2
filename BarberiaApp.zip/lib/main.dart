import 'package:flutter/material.dart';
import './Widgets/MyApp.dart';

void main() => runApp(MyApp());
