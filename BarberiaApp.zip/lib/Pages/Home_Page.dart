import 'package:flutter/material.dart';

// Importa el paquete 'flutter/material', necesario para construir la interfaz de la aplicación.

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

// Clase de la página principal que extiende 'StatefulWidget'.

class _HomePageState extends State<HomePage> {
  final String apiUrl = "https://www.datos.gov.co/resource/e27n-di57.json";

  // URL del endpoint que se va a utilizar.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.restaurant_menu),
            SizedBox(width: 10),
            Text(
              'Salon',
              textAlign: TextAlign.center,
            )
          ],
        ),
        backgroundColor: Colors.black,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "https://www.datos.gov.co/resource/e27n-di57.json",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              apiUrl,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}

// La clase _HomePageState es un estado mutable de la página principal que se construye cuando se ejecuta 'createState()'.
// El método 'build' devuelve la estructura de la página principal utilizando Widgets de Flutter.
// Se muestra una AppBar con un ícono y texto centrados, y dos Text Widgets que muestran la URL del endpoint.
