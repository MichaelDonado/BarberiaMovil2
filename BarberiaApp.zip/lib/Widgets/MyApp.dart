import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Salon',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const MyHomePage(title: 'Salon'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late Future<List<Salon>> _listadoSalon;
  Future<List<Salon>> _getSalon() async {
    final response = await http
        .get(Uri.parse("https://www.datos.gov.co/resource/e27n-di57.json"));
    if (response.statusCode == 200) {
      Iterable list = json.decode(response.body);
      return list.map((model) => Salon.fromJson(model)).toList();
    } else {
      throw Exception("Fallo la conexión");
    }
  }

  @override
  void initState() {
    _listadoSalon = _getSalon();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: FutureBuilder<List<Salon>>(
        future: _listadoSalon,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  color: Colors.white,
                  child: ListTile(
                    leading: Icon(Icons.store, color: Colors.orange),
                    title: Text(
                        snapshot.data![index].razonSocial ?? "Sin nombre",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle:
                        Text(snapshot.data![index].direccionComercial ?? ""),
                    trailing: Icon(Icons.arrow_forward_ios),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}

class Salon {
  final String? razonSocial;
  final String? direccionComercial;

  Salon({this.razonSocial, this.direccionComercial});

  factory Salon.fromJson(Map<String, dynamic> json) {
    return Salon(
      razonSocial: json["razon_social"],
      direccionComercial: json["direccion_comercial"],
    );
  }
}
